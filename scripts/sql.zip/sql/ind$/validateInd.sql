use `farmcafe`;
DROP procedure IF EXISTS `validateInd$DonId`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `validateInd$DonId`(in donation_id char(6), out new_id char(6))
BEGIN
/*remove*/
select $.org_id
from ind_mon_don as $
where $.ind_mon_id like donation_id
into new_id
;
END$$

DELIMITER ;
