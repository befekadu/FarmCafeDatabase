use `farmcafe`;
DROP procedure IF EXISTS `insertInd$Don`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertInd$Don`(
in ind_mon_id char(6),
in don_value double(8,2),
in don_date date,
in reciept_date date,
in ind_don_id char(5),
in pay_type enum('paypal')
)
BEGIN
/*remove*/
insert into ind_mon_don values(
ind_mon_id,
don_value,
don_date,
reciept_date,
ind_don_id,
pay_type
);
END$$

DELIMITER ;

