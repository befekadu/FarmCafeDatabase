use `farmcafe`;
DROP procedure IF EXISTS `count_ind_mon_don`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_ind_mon_don`(out count int)
BEGIN
/*remove*/
select count(*) into count from ind_mon_don;
END$$

DELIMITER ;


