use `farmcafe`;
DROP procedure IF EXISTS `count_event_don`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_event_don`(out count int)
BEGIN
/*remove me*/
select count(*) into count from event_don;
END$$

DELIMITER ;


