use `farmcafe`;
DROP procedure IF EXISTS `validateOrgId`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `validateOrgId`(in org_id Char(5), out new_id Char(5))
BEGIN
/*remove me */
select O.org_id
from org_donor as O
where O.org_id like org_id
into new_id
;
END$$

DELIMITER ;

