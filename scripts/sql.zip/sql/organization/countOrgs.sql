use `farmcafe`;
DROP procedure IF EXISTS `count_org_donors`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_org_donors`(out count int)
BEGIN
/*remove me*/
select count(*) from org_donor into count;
END$$

DELIMITER ;


