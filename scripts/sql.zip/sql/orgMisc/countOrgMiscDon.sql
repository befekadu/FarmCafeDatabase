use `farmcafe`;
DROP procedure IF EXISTS `count_org_misc_don`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_org_misc_don`(out count int)
BEGIN
/*remove me*/
select count(*) into count from org_misc_don;
END$$

DELIMITER ;


