use `farmcafe`;
DROP procedure IF EXISTS `count_org_mon_don`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_org_mon_don`(out count int)
BEGIN
/*remove me*/
select count(org_mon_don) into count;
END$$

DELIMITER ;


