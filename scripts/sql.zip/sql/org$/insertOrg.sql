USE `farmcafe`;
DROP procedure IF EXISTS `insertOrg$Donor`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertOrg$Donor`(
in org_mon_id char(6), 
in don_value double(8,2),
don_date date,
reciept_date date,
org_don_id char(5)
)
BEGIN
/*remove me*/
insert into org_mon_don values(
org_mon_id,
don_value,
don_date,
reciept_date,
org_don_id
);

END$$

DELIMITER ;
