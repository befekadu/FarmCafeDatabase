use `farmcafe`;
DROP procedure IF EXISTS `validateOrg$DonId`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `validateOrg$DonId`(in donation_id char(6), out new_id char(6))
BEGIN
/*remove me*/
select $.org_mon_id
from org_mon_don as $
where $.org_mon_id like donation_id
into new_id
;
END$$

DELIMITER ;


