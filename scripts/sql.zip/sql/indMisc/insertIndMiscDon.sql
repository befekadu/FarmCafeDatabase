use `farmcafe`;
DROP procedure IF EXISTS `insertIndMiscDon`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertIndMiscDon`(in ind_misc_id char(6), in don_date date, in description text, in ind_don_id char(5))
BEGIN
/*remove me*/
insert into ind_misc_donor values(
ind_misc_id,
don_date,
description,
ind_don_id
);
END$$

DELIMITER ;

