use `farmcafe`;
DROP procedure IF EXISTS `count_ind_misc_don`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_ind_misc_don`(out count int)
BEGIN
/*remove*/
select count(*) into count from ind_misc_don;
END$$

DELIMITER ;

