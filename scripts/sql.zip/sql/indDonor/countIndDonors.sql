use `farmcafe`;
DROP procedure IF EXISTS `count_ind_donors`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER='root'@`localhost` PROCEDURE `count_ind_donors`(OUT count INT)
BEGIN
SELECT COUNT(*) INTO count FROM ind_donor;
END$$

DELIMITER ;

