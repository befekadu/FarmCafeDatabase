use `farmcafe`;
DROP procedure IF EXISTS `validateDonorId`;

DELIMITER $$
USE `farmcafe`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `validateDonorId`(in don_id char(5), out new_id char(5))
BEGIN
/*remove me*/
select D.don_id
from ind_donor as D
where D.don_id like don_id
into new_id
;
END$$

DELIMITER ;


